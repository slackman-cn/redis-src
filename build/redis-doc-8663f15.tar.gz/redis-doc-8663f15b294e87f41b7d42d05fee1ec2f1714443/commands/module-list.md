Returns information about the modules loaded to the server.
