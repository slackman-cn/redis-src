The `SCRIPT HELP` command returns a helpful text describing the different subcommands.
