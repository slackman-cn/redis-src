Returns `message`.

@examples

```cli
ECHO "Hello World!"
```
