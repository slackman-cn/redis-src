The `REPLCONF` command is an internal command.
It is used by a Redis master to configure a connected replica.