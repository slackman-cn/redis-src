Removes the specified keys.
A key is ignored if it does not exist.

@examples

```cli
SET key1 "Hello"
SET key2 "World"
DEL key1 key2 key3
```
