This is a container command for client connection commands.

To see the list of available commands you can call `CLIENT HELP`.